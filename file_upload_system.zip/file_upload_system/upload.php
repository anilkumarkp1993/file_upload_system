<?php
session_start();
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
?>
<?php

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File Upload</title>
     <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Upload a File</h1>
    <form action="upload_handler.php" method="post" enctype="multipart/form-data">
        Select a file to upload <b><font color="red">(jpg, png, pdf, docx)</font></b>:<br>
        <b><font color="red">Maximum allowed file size is 5mb</font></b><br><br>
        <input type="file" name="file" id="file" required>
        <input type="submit" value="Upload File">
    </form>
     <div id="imageContainer"></div>
    <p><a href="upload_history.php">View Upload History</a></p>
    <p><a href="log.php">View Logs</a></p>
    <p><a href="login.php">Back to Login page</a></p>
    <p><a href="index.php">Back to Main page</a></p>
    <p><a href="logout.php">Logout</a></p>
    
</body>
</html>