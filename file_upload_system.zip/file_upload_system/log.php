<?php
session_start();
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
?>

<?php

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit;
}


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "file_upload";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$userId = $_SESSION['user_id'];
$sql = "SELECT filename, upload_timestamp,reason,ip_address FROM logs WHERE user_id = $userId";
$result = $conn->query($sql);

$uploadDir = 'secure_uploads/';

if ($result->num_rows > 0) {
    echo "<h1>View logs</h1>";
     echo "<div><a href='upload.php' class='button-link'>Back to Upload page</a></div><br>";
    echo "<table border='1'>";
    echo "<tr><th>Filename</th><th>Upload Timestamp</th><th>Status/Reason</th><th>IP Addres</th></tr>";
    while ($row = $result->fetch_assoc()) {

        echo "<tr>";
         $fileExtension = pathinfo($row['filename'], PATHINFO_EXTENSION);

       
         echo "<td>";
        
        if (in_array($fileExtension, ['pdf', 'docx'])) {
            // Display a PDF or DOCX icon based on the file extension
            echo "<img src='icons/$fileExtension.png' alt='File Icon' width='200px' height='100px'>";
             echo "<a href='".$uploadDir.$row['filename']."' download>Download</a>";
        } else {
            // Display an image for other file types
            echo "<img src='" . $uploadDir . $row['filename'] . "' alt='Uploaded Image' width='200px' height='100px'>";
        }

        echo "</td>";

        echo "<td>" . $row['upload_timestamp'] . "</td>";
        echo "<td>" . $row['reason'] . "</td>";
        echo "<td>" . $row['ip_address'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No logs found.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Uploader</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
   </head>
<body>
    
  
    </body>
    </html>

