<?php
session_start();
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];

    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "file_upload";

    $conn = new mysqli($servername, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    
    $query = "INSERT INTO user (username, password, phone) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);

    
    $stmt->bind_param("sss", $username, $hashedPassword, $phone);

    if ($stmt->execute()) {
        echo "<br><h2>Registration successful. <a href='login.php'>Login</a></h2>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
   </head>
<body>
    <div class="container">
        <h1>Registration</h1>
        <form method="post" action="register.php">
            <label for="username">Username:</label>
            <input type="text" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" name="password" required><br>
            <label for="phone">Phone:</label>
            <input type="tel" name="phone" required><br>
            <input type="submit" value="Register">
        </form>
    </div>
</body>
</html>
