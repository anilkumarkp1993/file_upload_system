<?php
session_start();
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
?>
<?php


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uploadDir = 'secure_uploads/';
$allowedExtensions = array('jpg', 'png', 'pdf', 'docx');
$maxFileSize = 5 * 1024 * 1024; // 5MB


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "file_upload";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    if ($_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $fileExtension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

        if (in_array($fileExtension, $allowedExtensions)) {
           
            if ($_FILES['file']['size'] <= $maxFileSize) {
               
                $uniqueFilename = uniqid() . '_' . $_FILES['file']['name'];
                $uploadPath = $uploadDir . $uniqueFilename;

               
                if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath)) {
                   
                    $userId = $_SESSION['user_id'];
                    $filename = $uniqueFilename;
                    $timestamp = date('Y-m-d H:i:s');
                    
                   
                    $ipAddress = $_SERVER['REMOTE_ADDR'];

                    
                    $sql = "INSERT INTO uploads (user_id, filename, upload_timestamp) VALUES ('$userId', '$filename', '$timestamp')";
                   
                    $conn->query($sql);

                   
                    $sql = "INSERT INTO logs (user_id, ip_address, filename, upload_timestamp,reason) VALUES ('$userId', '$ipAddress', '$filename', '$timestamp','success')";
                   
                    $conn->query($sql);

                    echo "<h3 class='fus'><font color='green'>File uploaded successfully!</font></h3>";
                } else {
                    echo "File upload failed.";
                }
            } else {
                echo "File size exceeds the limit.";
            }
        } else {
                $userId = $_SESSION['user_id'];
                $uniqueFilename = uniqid() . '_' . $_FILES['file']['name'];
                $filename = $uniqueFilename;
                $timestamp = date('Y-m-d H:i:s');
                $ipAddress = $_SERVER['REMOTE_ADDR'];
                $sql = "INSERT INTO logs (user_id, ip_address, filename, upload_timestamp, reason) VALUES ('$userId', '$ipAddress', '$filename', NOW(), 'Invalid file type')";
            $conn->query($sql);
            echo "<h3 class='fus'><font color='green'>Invalid file type.</font></h3>";
        }
    } else {
        echo "File upload error.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Uploader</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
   </head>
<body>
    
    <form action="upload.php" method="get">
            <button type="submit">Back to Upload Page</button>
        </form>

    </body>
    </html>
