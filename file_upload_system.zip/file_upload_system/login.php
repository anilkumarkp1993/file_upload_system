<?php
session_start();
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

   

    
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "file_upload";

    $conn = new mysqli($servername, $db_username, $db_password, $db_name);

   
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
    $query = "SELECT id, username, password FROM user WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    //$stmt->store_result();
    
    if ($result->num_rows >= 1) {
    while ($row = $result->fetch_assoc()) {
        $userId = $row['id'];
        $dbUsername = $row['username'];
        $dbPassword = $row['password'];

        if (password_verify($password, $dbPassword)) {
            $_SESSION['user_id'] = $userId; 
            header("Location: upload.php"); 
            exit;
        }
    }
} else {
    $loginError = "Invalid username or password.";
}

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" name="password" required><br>
            <input type="submit" value="Login">
        </form>
        <?php
        if (isset($loginError)) {
            echo "<p class='error'>$loginError</p>";
        }
        ?>
    </div>
</body>
</html>
