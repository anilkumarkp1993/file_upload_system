<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Secure File Upload System Development</title>
      <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Welcome to Secure File Upload System Development</h1>
    
   <p class="hdng">Please choose an option:</p>
    
    <div class="button-container">
    	<div class="hdng">
        <form action="login.php" method="get">
           <center> <button type="submit">Login</button></center>
        </form>
        
        <form action="register.php" method="get">
            <center><button type="submit">Registration</button></center>
        </form>
    </div>
    </div>
</body>
</html>
